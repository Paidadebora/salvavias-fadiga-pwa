# Salva-Vias — PWA de Detecção de Fadiga (Offline)

**GitHub Pages Automático** — pronto para publicar com um comando no Windows PowerShell.

## Publicar (1 comando)
```powershell
./deploy.ps1
```
> Repositório alvo: https://github.com/paidadebora/salvavias-fadiga-pwa

## Alternativa macOS/Linux
```bash
bash deploy.sh
```

## iPhone (Safari)
1. Acesse: https://paidadebora.github.io/salvavias-fadiga-pwa/
2. Compartilhar → **Adicionar à Tela de Início**.
3. Primeiro acesso precisa de internet; depois funciona **offline**.
